import React from "react";

export default function App() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-100 to-white text-center p-8">
      <h1 className="text-4xl font-bold text-purple-700 mb-4">
        Bienvenido a Servicios Holísticos
      </h1>
      <p className="text-lg text-gray-700 mb-8 max-w-xl mx-auto">
        Un espacio para conectar con terapeutas de confianza, explorar terapias alternativas
        y encontrar equilibrio en tu vida.
      </p>
      <button className="bg-purple-600 text-white px-6 py-3 rounded-full hover:bg-purple-700 transition">
        Registrate como Terapeuta
      </button>
    </div>
  );
}